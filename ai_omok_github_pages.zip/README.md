# AI 오목 게임

브라우저에서 AI와 1:1로 대결할 수 있는 15×15 오목 게임입니다.

## 주요 기능

- 15×15 오목판
- 플레이어는 흑돌, AI는 백돌
- AI의 공격 및 방어 판단
- 5목 승리 판정
- 즉시 승리/위협 차단
- 무승부 판정
- 새 게임 버튼
- PC 및 모바일 브라우저 대응
- 별도의 서버나 데이터베이스 없이 동작

## GitHub Pages로 배포하기

### 1. GitHub 저장소 만들기

GitHub에서 새 Repository를 만든 뒤 이 프로젝트의 파일을 업로드합니다.

필요한 파일:

```text
index.html
README.md
```

### 2. 파일 업로드

GitHub 저장소에서

**Add file → Upload files**

를 선택하고 `index.html`과 `README.md`를 업로드합니다.

### 3. GitHub Pages 활성화

저장소의

**Settings → Pages**

로 이동합니다.

**Build and deployment**에서 다음과 같이 설정합니다.

- Source: `Deploy from a branch`
- Branch: `main`
- Folder: `/ (root)`

저장 후 잠시 기다리면 GitHub Pages 주소가 생성됩니다.

일반적으로 다음과 같은 형태입니다.

```text
https://사용자이름.github.io/저장소이름/
```

## 로컬에서 실행

`index.html`을 크롬 등의 웹 브라우저에서 열면 바로 플레이할 수 있습니다.

## 기술

- HTML
- CSS
- Vanilla JavaScript
- Canvas API

별도의 라이브러리나 빌드 과정이 필요하지 않습니다.
